import Header from './Header'
import SidebarNav from './Sidenav'

export default function AdminLayout(){
    return(
        <>
            <Header />
            <SidebarNav/>
            
        </>
    )
}
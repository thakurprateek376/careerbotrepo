
export default function CareerGPTHeader(){
    return (
        <>
            <h1 style={{
                fontSize: "28px",
                textAlign: "center",
                color: "#81689D"
            }}>
                Career GPT
            </h1>
        </>
    )
}
import FooterCSS from "../assets/styles/Footer.module.css"

export default function Footer(){
    return (
        <h1>Footer</h1>
    )
}